"""
Allow running as: python -m gateway_agent
"""

from .main import main

if __name__ == "__main__":
    main()
